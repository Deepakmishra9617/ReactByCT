import React from "react";
function AddBooks() {
    return (
  
    <form style={{border:'2px solid grey',boxShadow:"0 0 10px 5px grey",height:'450px' ,width:"320px",justifyContent:"center",alignItems:"center",margin:'auto',marginTop:'50px',paddingLeft:"40px",paddingTop:"20px",marginLeft:"40%"}}>
        <h3>Add Book</h3>
        Book Name : <br /><input type="text" name="book" placeholder="Book Name"></input> <br />
        Book Image: <br /><input type="url" name="image" placeholder="Book Image URL"></input> <br />
        Author Name : <br /><input type="text" name ="author" placeholder="Author Name"></input> <br />
        Book description : <br /><input type="text" name="description" placeholder="Book Description"></input> <br />
        book Price : <br /><input type="number" name="price" placeholder="Book Price"></input> <br />
        category : <br /><input type="box" name="category" placeholder="Category"></input> <br />
        <br /> <button type="submit"> Add Books</button>
               </form>
    )
}
export default AddBooks;