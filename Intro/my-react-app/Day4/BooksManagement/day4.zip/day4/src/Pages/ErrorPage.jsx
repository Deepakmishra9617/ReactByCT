import React from 'react'

function ErrorPage() {
  return (
    <div>
      <h1 className="text-danger text-center mt-3">ErrorPage</h1>
    </div>
  )
}

export default ErrorPage
