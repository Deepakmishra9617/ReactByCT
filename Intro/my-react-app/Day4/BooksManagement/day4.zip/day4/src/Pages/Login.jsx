import React from 'react'

function Login() {
  return (
    <form style={{border:"2px solid grey",height:"280px",width:"300px",justifyContent:"center",alignItems:"center",boxShadow:"0px 0px 10px 5px grey",margin:"auto",marginTop:"100px",paddingLeft:"40px",paddingTop:"20px"}}>
        <h3>Login</h3>
        Username : <br/> <input type ="text" name = "username" placeholder='Username'/><br/>
        Password : <br /> <input type ="password" name="password" placeholder="password"/><br/>
        <br />
        <button style={{borderRadius:"5px",border:"2px solid blue", backgroundColor:"blue", color:"white",padding:"5px 10px"
        }}>Login</button>
        <br/> Don't have an account? <a href="/signup">Signup</a>
    </form>
  )
}

export default Login
