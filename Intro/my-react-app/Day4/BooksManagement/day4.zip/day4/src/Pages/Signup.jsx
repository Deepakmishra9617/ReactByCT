import React, { useState } from 'react'
import { Form } from 'react-router-dom'
import { Link } from "react-router-dom"

function Signup() {

  const [errors, setErrors] = useState({});

  const [formData, setformData] = useState({
    userName: "",
    email: "",
    contact: "",
    password: "",
    address: ""
  });

  const formValidator = () => {
    let newErrors = {};
    let { userName, email, contact, password, address } = formData;

    if (userName.trim().length < 2) {
      newErrors.userName = "Username must be at least 2 characters long";
    }

    const isValidName = /^[a-zA-Z]+$/;
    if (!isValidName.test(userName)) {
      newErrors.userName = "Username can only contain letters";
    }

    const isvalidEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!isvalidEmail.test(email)) {
      newErrors.email = "Invalid Email";
    }

    const isvalidContact = /^\d{10}$/;
    if (!isvalidContact.test(contact)) {
      newErrors.contact = "Contact must be a 10-digit number";
    }

    let isvalidPassword = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/;
    if (!isvalidPassword.test(password)) {
      newErrors.password = "Invalid Password";
    }


    // No validation for address as per requirements


    if(address.trim().length ===0){
      newErrors.address = "Address is required";
    }


    return newErrors;
  };


  const changeHandler = (e) => {
    let { name, value } = e.target;
    setformData((prev) => ({
      ...prev,
      [name]: value,
    }));
  }

  const submitHandler = (e) => {
    e.preventDefault();

    const validateErrors = formValidator();
    setErrors(validateErrors);

    if (Object.keys(validateErrors).length === 0) {
      alert("Form submitted successfully");
      setformData({
        userName: "",
        email: "",
        contact: "",
        password: "",
        address: "",
      });
    }
  };


  return (
    <div style={{
      display: "flex",
      justifyContent: "center",
      alignItems: "flex-start",
      minHeight: "90vh",
      paddingTop: "50px",
      backgroundColor: "#f8f8f8"
    }}>
      <form className='form-box' onSubmit={submitHandler} style={{
        height: "430px", width: "320px", justifyContent: "center", alignItems: "center",
        boxShadow: "0px 0px 10px 5px grey", margin: "auto", paddingLeft: "40px", paddingTop: "20px",
        border: "5px solid",
        borderImage: "linear-gradient(45deg, red, orange, yellow, green, blue, indigo, violet) 1",
      }}>

        <h3>SignUp</h3>

        <label htmlFor="u-name">Username:</label>
        <br />
        <input type="text" name="userName" id="u-name"
          value={formData.userName} onChange={changeHandler} /><br />

        {errors.userName && (
          <span style={{ color: "red" }}>{errors.userName}</span>
        )}
        <br />

        <label htmlFor="email">Email:</label>
        <br />
        <input type="email" name="email" id="email" value={formData.email} onChange={changeHandler} />
        <br />
        {errors.email && <span style={{ color: "red" }}>{errors.email}</span>}
        <br />

        <label htmlFor="contact">Contact:</label>
        <br />
        <input type="number" name="contact" id="contact" value={formData.contact} onChange={changeHandler} />
        <br />
        {errors.contact && <span style={{ color: "red" }}>{errors.contact}</span>}
        <br />

        <label htmlFor="password">Password:</label>
        <br />
        <input type="password" name="password" id="password" value={formData.password} onChange={changeHandler} /><br />
         {errors.password && <span style={{ color: "red" }}>{errors.password}</span>} <br />

        <label htmlFor="address">Address:</label>
        <br />
        <input type="text" name="address" id="address" value={formData.address} onChange={changeHandler} /><br />
 {errors.address && <span style={{ color: "red" }}>{errors.address}</span>}
        <br />
        <button type="submit" style={{
          border: "2px solid red", color: "white",
          borderRadius: "6px", backgroundColor: "red"
        }}>Signup</button>

        <br />
        Already have an account? <a href="/login">Login</a>
        <Link to="/login" /> Already have an account? Login
      </form>
    </div>

  )
}

export default Signup;
